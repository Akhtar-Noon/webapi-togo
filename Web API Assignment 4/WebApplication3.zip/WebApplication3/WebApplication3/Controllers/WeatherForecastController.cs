﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Text.Json;

namespace WebApplication3.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {

        WeatherData1 test = new WeatherData1();
        WeatherData2 test2 = new WeatherData2();
       

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }
        // get all enteries names
        [Route("infobooks")]
        [HttpGet]
        public List<string> GetNamesofBooks()
        {
            List<string> names = new List<string>();
            foreach (Book x in test.GetBookList())
            {
                names.Add(x.name);
            }
            return names;
        }
        // get all user names
        [Route("infouser/{id}")]
        [HttpGet]
        public List<Book> GetUser(int ID)
        {
           foreach(var y in test2.GetUserList())
            {
                if(y.id==ID)
                {
                    return y.GetIssuedList();
                }
            }
            return null;
        }
        // insert user
        [Route("insertuser")]
        [HttpPost]
        public void AddUser([FromBody] User userone)
        {
            test2.InsertUser(userone);
        }
        // get book by id
        [Route("infobooksfetch/{bookname}")]
        [HttpGet]
        public string GetBookbyName(string bookname)
        {
            foreach (var x in test.GetBookList())
            {
                if (x.name == bookname)
                {
                    if (x.issued == false)
                    {
                        return "name: "+x.name+"  Category: "+x.category+"  shelf: "+x.shelf+"  Price: "+x.price;
                    }
                    else
                    {
                        return "the book is already issued";
                    }
                }
            }
            return "The book is not in collection"; 
        }
        // get list book issued by user
        [Route("infouserbyname/{uname}")]
        [HttpGet]
        public List<Book> GetBookbyuserName(string uname)
        {
            test2.dosomething();
            foreach (var z in test2.GetUserList())
            {
                if(z.username==uname)
                {
                    return z.UserIssued ;
                }
            
            }
            return null;
        }
        // insert book

        [Route("insertbook")]
        [HttpPost]
        public void Addbook([FromBody] Book bookone)
        {
            test.InsertBook(bookone);
        }
        // update book
        [Route("updatebook/{bookname}")]
        [HttpPut]
        public void updatebook(string bookname,[FromBody] Book b)
        {
            List<Book> temp = test.GetBookList();
            for(int x=0;x<temp.Count;x++)
            {
                if(temp[x].name==bookname)
                {
                    temp[x].name = b.name;
                    temp[x].price = b.price;
                    temp[x].category = b.category;
                    temp[x].shelf = b.shelf;

                }
            }
        }

        //updateuser
        [Route("updateuser/{nameofuser}")]
        [HttpPut]
        public List<User> updateuserk(string nameofuser, [FromBody] User newuser)
        {
            List<User> temp = test2.GetUserList();
            for (int x = 0; x < temp.Count; x++)
            {
                if (temp[x].username == nameofuser)
                {
                    temp[x].username = newuser.username;
                    temp[x].id = newuser.id;
                    temp[x].UserIssued.Clear();

                }
            }
            return temp;
        }
        // issue book
        [Route("issuebook/{nameofuser}")]
        [HttpPut]
        public List<Book> Issue(string nameofuser, [FromBody] Book getthis)
        {
            List<Book> temp1 = test.GetBookList();
            List<User> temp2 = test2.GetUserList();
            Book thisbook = null; 
            User thisuser=null;
            int indexbook=0;
            int indexuser=0;
            for (int x=0;x<temp1.Count;x++)
            {
                if(temp1[x].name==getthis.name)
                {
                    thisbook = temp1[x];
                    indexbook = x;

                }
            }
            for (int x = 0; x < temp2.Count; x++)
            {
                if (temp2[x].username == nameofuser)
                {
                    thisuser = temp2[x];
                    indexuser = x;
                }
            }
            if (temp1[indexbook].issued == false)
            {
                temp1[indexbook].issued = true;
                temp2[indexuser].UserIssued.Add(thisbook);
            }
            return temp2[indexuser].GetIssuedList();
        }
        // delete book
        [Route("removebook/{nameofbook}")]
        [HttpDelete]
        public List<Book> deletethisbook(string nameofbook)
        {
            List<Book> temp1 = test.GetBookList();
            List<User> temp2 = test2.GetUserList();
            Book thisbook = null;
            int indexbook = 0;
            for (int x = 0; x < temp1.Count; x++)
            {
                if (temp1[x].name == nameofbook)
                {
                    thisbook = temp1[x];
                    indexbook = x;

                }
            }
            for (int x=0; x < temp2.Count;x++)
            {
                temp2[x].UserIssued.Remove(thisbook);
            }
            temp1.Remove(thisbook);
            return temp1;

        }
        // remove user by name
        [Route("removeuser/{nameofuser}")]
        [HttpDelete]
        public List<User> deletethisuser(string nameofuser)
        {
            List<User> temp2 = test2.GetUserList();
            User thisuser = null;
            for (int x = 0; x < temp2.Count; x++)
            {
                if (temp2[x].username == nameofuser)
                {
                    thisuser = temp2[x];
                    
                }
            }
            if(thisuser.UserIssued.Count==0)
            {
                temp2.Remove(thisuser);
            }
            return temp2;
        }
        // return book
        [Route("returnbook/{nameofbook}")]
        [HttpDelete]
        public void returnbook(string nameofbook)
        {
            List<Book> temp1 = test.GetBookList();
            List<User> temp2 = test2.GetUserList();
            Book thisbook = null;
            int indexbook = 0;
            for (int x = 0; x < temp1.Count; x++)
            {
                if (temp1[x].name == nameofbook)
                {
                    thisbook = temp1[x];
                    indexbook = x;
                }
            }
            for (int x = 0; x < temp2.Count; x++)
            {
                temp2[x].UserIssued.Remove(thisbook);

            }
            temp1[indexbook].issued = false;

        }


    }
}

