using System;
using System.Collections.Generic;

namespace WebApplication3
{
    public class WeatherForecast
    {
        public DateTime Date { get; set; }

        public int TemperatureC { get; set; }

        public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);

        public string Summary { get; set; }
    }
    public class Book
    {
        public int price { get; set; }
        public int shelf { get; set; }
        public string name { get; set; }
        public string category { get; set; }
        public bool issued = false;
    }
    public class User
    {
        public int id { get; set; }
        public string username { get; set; }
        public List<Book> UserIssued=new List<Book>();
        public List<Book> GetIssuedList()
        {
            return UserIssued;
        }
    }
}

