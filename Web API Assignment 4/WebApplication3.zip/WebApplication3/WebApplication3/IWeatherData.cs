﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
namespace WebApplication3
{
    public interface IWeatherData1
    {
        public List<Book> GetBookList();
        public int InsertBook(Book book);

    }
    public interface IWeatherData2
    {
        public List<User> GetUserList();

    }
}
