﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Linq.Expressions;
namespace WebApplication3
{
    public class WeatherData1 
    {
        static public List<Book> books = new List<Book>
        {
                new Book {name="Harry Potter",category="Sci-Fi",price=100,shelf=1,issued=true},
                new Book {name="Tom Hardy",category="Fiction",price=200,shelf=2},
                new Book {name="Land Earth",category="Sci-Fi",price=300,shelf=3},
                new Book {name="Jack of Trades",category="Crime",price=500,shelf=4},
                new Book {name="The Great Debate",category="politics",price=150,shelf=2,issued=true},
                new Book {name="Journey",category="Fairy Tale",price=170,shelf=3},
                new Book {name="Magic Room",category="Sci-Fi",price=180,shelf=4},
                new Book {name="Walle",category="Sci-Fi",price=188,shelf=7},
                new Book {name="Jumanji",category="Fiction",price=140,shelf=9},
                new Book {name="ABC",category="Fiction",price=141,shelf=10},
                new Book {name="Heliox",category="Science",price=131,shelf=11},
                new Book {name="Omega",category="Exotic",price=121,shelf=12,},
                new Book {name="Demigod",category="Fiction",price=111,shelf=3},
                new Book {name="Alpha",category="History",price=105,shelf=13},
                new Book {name="Majestic",category="Geography",price=112,shelf=14},
                new Book {name="Heatnix",category="Fiction",price=131,shelf=15},
                new Book {name="Zero",category="Anime",price=91,shelf=16},
                new Book {name="Megaman",category="Fiction",price=98,shelf=17},
                new Book {name="Dexter",category="Anime",price=124,shelf=9},
                new Book {name="Dee Dee",category="Cartoon",price=128,shelf=10},
        };

        
         public int DeleteBook(int DeleteBookIndex)
        {
            throw new NotImplementedException();
        }

        public List<Book> GetBookList()
        {
            return books;
        }

        public void InsertBook(Book book)
        {
            books.Add(book);
        }
    }
    public class WeatherData2
    {
        static public List<User> users = new List<User>
        {
            new User{id=1,username="Ahmad Mustafa" },
            new User{id=2,username="Arsalan Amin"},
            new User{id=3,username="Eishal"},
            new User{id=4,username="Irum"},
            new User{id=5,username="Isha"},
            new User{id=6,username="Naila"},
            new User{id=7,username="Irum"},
            new User{id=8,username="Nihal"},
            new User{id=9,username="Seemal"},
            new User{id=10,username="Anaya"},
        };
        public void dosomething()
        {
            Book temp1 = new Book() { name = "Harry Potter", category = "Sci-Fi", price = 100, shelf = 1 };
            Book temp2 = new Book() { name = "The Great Debate", category = "politics", price = 150, shelf = 2 };
            users[0].UserIssued.Add(temp1);
            users[0].UserIssued.Add(temp2);
        }

        public List<User> GetUserList()
        {
            return users;
        }
        public void InsertUser(User addme)
        {
             users.Add(addme);
        }
    }

}
